def add(x, y):
    """Add two numbers."""
    return x + y
