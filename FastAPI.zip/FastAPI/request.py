
import openai

# Set your OpenAI API key
openai.api_key = "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"

# Call the 'Completion.create' method to generate text completions
response = openai.Completion.create(
    engine="text-davinci-002",  # Choose a supported language model
    prompt="top 10 tech company",
    max_tokens=50
)

# Print the generated completion
print(response.choices[0].text)
