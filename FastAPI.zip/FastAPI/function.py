from transformers import pipeline

# Load the pre-trained BERT model for generating job descriptions
model_name = "distilbert-base-uncased-finetuned-squadv2"
nlp = pipeline("text2text-generation", model=model_name)

# Generate a job description based on the job title
job_title = "Software Engineer"
generated_job_description = nlp(f"Generate a job description for the job title: {job_title}")

# Print the generated job description
print(generated_job_description[0]['generated_text'])